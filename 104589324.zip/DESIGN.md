<!-- Design
To design my project, I tried to be very diverse in the resources I used because I wanted to teach myself to use JavaScript and APIs, as well as be more flexible in using Python interchangeably. While the Register, Log In, and Budget Analysis borrowed from the Finance PSet as a basic framework, the other pages differ.

Overall Theme/CSS/Stylistic choices
For the color scheme of my website, I am using neutral colors and shades of red to evoke a relaxed mood, but there also blue accents. The font is also meant to be readable but elegant. The website logo, which is a Bootstrap icon, is a die displaying a one to signify being first. The website uses Bootstrap cards throughout because they organize information in a manner that is easy to understand.

Blog
The blog page functions by taking a blog title and content as user input and storing it in blog.db, then displaying that information alongside username and date posted. I designed it using SQL because it would be easy to sort data by date, as well as link users with their posts using a database.
https://codewithawa.com/posts/how-to-create-a-blog-in-php-and-mysql-database
https://technosmarter.com/php/how-to-create-blog-using-php-and-mysql-database

Budget
Because the point of budget is to display to users their spending habits based on transaction count, I used an HTML form and SQL to store this information. HTML forms already have many convenient features. Once transaction details are stored in SQL, I used Python to query the database and store the user’s dollar amounts as an array. Then, using the Google Charts API, I pushed the arrays from Python into JavaScript and parsed them into inputs that Google Charts’ exiting line graph feature could use and drew them. I decided to use Google Charts for my line graph because it automatically takes care of scaling axes and producing a line function that fits the data and has a low coefficient of determination; this saved me a lot of math because I wouldn’t have to produce my own algorithms to produce a regression line. For the bar graph, however, I used Matplotlib in Python because it was more qualitative data. To get the number of transactions per category, I first used a SQL query; however, this produced a dictionary of lists of transaction counts, whereas Matplotlib only took in one 1D array for y-axis values. To remedy this, I flattened the data using a technique I found online, then drew the bar graph using Matplotlib’s existing documentation. I used both Google Charts and Matplotlib because I felt that each trumped the other in respect to the data I was trying to represent; for example, I wanted Google Charts to be more interactive because it is a line graph and users should be able to hover over certain points to know exactly how much they spent. With Matplotlib’s bar graph, however, a simple glance at categories is sufficient because bar graphs aren’t a function of transactions.

https://developers.google.com/chart/interactive/docs/gallery/linechart
https://stackoverflow.com/questions/30979962/matplotlib-plot-the-result-of-an-sql-query
https://blogs.solidq.com/en/sqlserver/python-for-sql-server-specialists-part-3-graphs-and-machine-learning/

Book
While I was originally planning on using a Goodreads API for the book finder, I discovered that the company had shut it down in December. I had to switch over to Google Books. I primarily used Javascript for this page, as the API recommended I do so. Based on user inputs of identities they align with, the page outputs book information as cards. I decided to use Bootstrap cards because I am displaying blocks of data, and I felt that I could easily append the HTML page.

https://developers.google.com/books

Quiz
This page of the website primarily uses Javascript rather than Python because I felt it allowed me to change HTML elements more conveniently. The High Scores part of the quiz works by storing user scores with their inputted names. The quiz itself functions within a Bootstrap card because I wanted to maintain the thematic layout of the website. The quiz functions by storing questions and answers as an array and matching them accordingly to determine if they are correct, then decrementing a time function if the user answers incorrectly. Once a question has been answered correctly, the quiz card resets its elements. I designed this portion of my code using a lot of the methods I had picked up from the Psets I’d completed in C and referencing forums.

https://www.sitepoint.com/simple-javascript-quiz/
https://webdevtrick.com/create-javascript-quiz-program/
https://www.w3schools.com/js/js_timing.asp
https://stackoverflow.com/questions/44314897/javascript-timer-for-a-quiz
https://www.w3schools.com/js/js_htmldom_html.asp

 Budget Analysis
This page was inspired by the history page from the finance Pset with an added JS element that allows users to search through their transactions. I designed it using SQL and JS because it made the most sense to display transactions as a table that users could reference based on what they were looking for. -->
