import os
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, \
    session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, \
    InternalServerError
from werkzeug.security import check_password_hash, \
    generate_password_hash
from helpers import apology, login_required
import re
db = SQL('sqlite:///budget.db')
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

app = Flask(__name__)

app.config['TEMPLATES_AUTO_RELOAD'] = True

app.config['SESSION_PERMANENT'] = False
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/book', methods=['GET', 'POST'])
def book():
    return render_template('book.html')


@app.route('/blog', methods=['GET', 'POST'])
@login_required
def blog():
    # Pulls up blog post using SQL query and user
    if request.method == 'POST':
        username = session['user_id']
        title = request.form.get('title')
        content = request.form.get('content')
        date = db.execute('SELECT date FROM blog WHERE username = ?',
                          session['username'])
        db.execute('INSERT INTO blog (username, title, content) VALUES(?,?,?)'
                   , session['username'], title, content)
        blog = db.execute('SELECT * FROM blog')
        return render_template('blog.html', blog=blog)
    else:
        blog = db.execute('SELECT * FROM blog')
        return render_template('blog.html', blog=blog)


@app.route('/budget', methods=['GET', 'POST'])
@login_required
def budget():
    if request.method == 'POST':
        transactiondetails = request.form.get('transactiondetails')
        categories = request.form.get('categories')
        amount = request.form.get('amount')
        db.execute('INSERT INTO budget (username, transactiondetails, categories, amount) VALUES(?,?,?, ?)'
                   , session['username'], transactiondetails,
                   categories, amount)
        # Amounts array to be filled with amounts user has spent
        amounts = []
        dateamount = \
            db.execute('SELECT * FROM budget WHERE username = ?',
                       session['username'])
        # Iterates through SQL query
        for (i, info) in enumerate(dateamount):
            amounts.append([i, info['amount']])
        # Pulls counts of each category based on username
        school = \
            db.execute("SELECT COUNT(*) FROM budget WHERE categories = 'school' AND username = ?"
                       , session['username'])
        recreation = \
            db.execute("SELECT COUNT(*) FROM budget WHERE categories = 'recreation' AND username = ?"
                       , session['username'])
        food = \
            db.execute("SELECT COUNT(*) FROM budget WHERE categories = 'food' AND username = ?"
                       , session['username'])
        fees = \
            db.execute("SELECT COUNT(*) FROM budget WHERE categories = 'fees' AND username = ?"
                       , session['username'])
        emergencies = \
            db.execute("SELECT COUNT(*) FROM budget WHERE categories = 'emergencies' AND username = ?"
                       , session['username'])
        # Counts transactions per category
        schoolcount = [d['COUNT(*)'] for d in school]
        recreationcount = [d['COUNT(*)'] for d in recreation]
        foodcount = [d['COUNT(*)'] for d in food]
        feescount = [d['COUNT(*)'] for d in fees]
        emergenciescount = [d['COUNT(*)'] for d in emergencies]

        # Bar chart x-axis names
        categorynames = ['School', 'Recreation', 'Food', 'Fees',
                         'Emergencies']
        # Bar chart y-axis amounts
        categoryvalues = [schoolcount, recreationcount, foodcount,
                          feescount, emergenciescount]
        # Flattens list of category counts to match the input of Google API
        flatcategoryvalues = [item for elem in categoryvalues
                              for item in elem]

        # Draws chart
        plt.bar(categorynames, flatcategoryvalues, color='maroon',
                width=0.4)
        plt.xlabel('Category')
        plt.ylabel('Transactions')
        plt.title('Categories vs. Transactions')
        # Saves chart as image that is constantly refreshed with updates
        plt.savefig('static/categorytransactions.png')

        return render_template('budget.html', amounts=amounts)
    else:

        dateamount = \
            db.execute('SELECT id, amount FROM budget WHERE username = ?'
                       , session['username'])
        amounts = []

        for (i, info) in enumerate(dateamount):
            amounts.append([i, info['amount']])

        return render_template('budget.html', amounts=amounts)


@app.route('/analysis', methods=['GET', 'POST'])
@login_required
def analysis():
    """Show history of transactions"""
    # SQL Query to pull transactions from database
    return render_template('analysis.html',
                           budgetanalysis=db.execute('SELECT * FROM budget WHERE username = ?'
                           , session['username']))


@app.route('/quiz')
def quiz():
    if request.method == 'POST':
        return render_template('quiz.html')
    else:
        return render_template('quiz.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Register user"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirmation = request.form.get('confirmation')
        if not username:
            return apology('must provide username')
        if not password or not confirmation:
            return apology('must fill in both passwords')
        if password != confirmation:
            return apology('passwords must match')
        hashedPassword = generate_password_hash(password)
        checkUser = \
            db.execute('SELECT username FROM users WHERE username = ?',
                       username)
        if len(checkUser) == 0:
            db.execute('INSERT INTO users (username, hash) VALUES(?, ?)'
                       , username, hashedPassword)
            return redirect('/')
        else:
            return apology('username already exists')
    else:
        return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Log user in"""
    session.clear()
    if request.method == 'POST':
        if not request.form.get('username'):
            return apology('must provide username', 403)
        elif not request.form.get('password'):
            return apology('must provide password', 403)
        rows = db.execute('SELECT * FROM users WHERE username = ?',
                          request.form.get('username'))
        if len(rows) != 1 or not check_password_hash(rows[0]['hash'],
                request.form.get('password')):
            return apology('invalid username and/or password', 403)
        session['user_id'] = rows[0]['id']
        session['username'] = request.form.get('username')
        return redirect('/')
    else:
        return render_template('login.html')

@app.route('/logout')
def logout():
    """Log user out"""
    session.clear()
    return redirect('/')
