// Quiz questions
var questions = [
    {
      title: 'What percent of students at Harvard are first-generation?',
      choices: ['15%', '19%', '20%', '30%'],
      answer: '15%'
    },
    {
      title: 'Which of the following is the first-gen student organization on campus?',
      choices: ['Harvard FG Association', 'PRIMUS', 'First', 'HFAI'],
      answer: 'PRIMUS'
    },
    {
      title: 'What is HFAI?',
      choices: ['Harvard First Gen Aid Initiative', 'Harvard for Artificial Intelligence', 'None of these options', 'Harvard Financial Aid Initiative'],
      answer: 'Harvard Financial Aid Initiative'
    },
    {
      title: 'What form do you fill out if you need emergency funding?',
      choices: ['Beneficiary Aid', 'HFAI Emergency Form', 'Emergency Aid Form', 'Emergency Fund Form'],
      answer: 'Beneficiary Aid'
    }
  ];