<!-- Summary
The premise of my project is to offer a centralized resource space for first-generation students through a web application that uses SQL, JavaScript, Python, HTML, and CSS. It offers students a place to budget their money and track their spending habits through visualizing behavior or searching through spending history. It also provides a space for students to interact with one another, as well as a quiz that tests their knowledge of the resources provided on campus.

Layout
The layout page includes the navigation bar and sticky footer. The footer includes links to contact me through email or phone, and the navigation bar prompts users to pages. Before the user has registered or logged in, the navigation bar also includes links to the Register and Log In page.

Index
This is the homepage of my web application and features its title as well as a carousel with a brief description of the website and a prompt motivating people to register. It also includes a map with the location Harvard Financial Aid Office, which users can easily navigate to.

Blog
The blog page features a brief description of why it is important to let out your thoughts. It also has a form that users can fill out to add a post to the page, which will appear on the bottom. The blog relies on SQL queries, as the title and the content of the blog are stored into the blog database. Users can also view blog posts from other users and when they were posted.

 Budget
The Budget page is where users can visually see the trends of their transactions; the goal is to make students more conscious of how often and where they spend their money. Users may input this information using an HTML form. From there, the data is stored into a SQL database. Because I wanted to educate myself on APIs and Matplotlib, I used two different ways to depict the data. The first graph, which is a line graph, uses the Google Charts API, Python, and JavaScript to depict Transactions vs. Amount Spent. The second graph is a bar graph that shows distributions across different categories solely from Python.

Book Finder
This page outputs book recommendations that are related to the college experience based on identities that students may align themselves with. It uses JavaScript and the Google Books API to match users with books.

Quiz
The Quiz page uses primarily JavaScript to test users on their knowledge of first-generation sources on campus. It also outputs a leadership board at the end with names of people that have taken the quiz.

Budget Analysis
This page allows users to search through their transactions so they can easily see how/where they have spent their money.

Implementation
To run this web application, you need Pandas, Matplotlib, Flask, and SQL. Some of the command-line arguments needed before running the application are pip install matplotlib and pip install pandas; it is then run using a Flask application.

VIDEO LINK: https://youtu.be/rvQckw0hknE
 -->
